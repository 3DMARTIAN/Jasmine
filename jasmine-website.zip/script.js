function showMessage() {
    alert("Bunga melati melambangkan kesucian dan ketenangan 🤍");
}
