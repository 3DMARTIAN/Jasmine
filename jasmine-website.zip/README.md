# 🤍 Jasmine (Melati) Website Project

Project website sederhana bertema bunga melati.

## Fitur
- Desain bersih dan elegan (putih & minimalis)
- Galeri gambar
- Tombol interaktif JavaScript

## Cara Menjalankan
1. Download project
2. Buka file index.html di browser

## Cocok Untuk
- Portfolio GitHub
- Belajar HTML, CSS, JavaScript dasar
